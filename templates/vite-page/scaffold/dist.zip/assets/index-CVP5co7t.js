(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const t of document.querySelectorAll('link[rel="modulepreload"]'))s(t);new MutationObserver(t=>{for(const a of t)if(a.type==="childList")for(const i of a.addedNodes)i.tagName==="LINK"&&i.rel==="modulepreload"&&s(i)}).observe(document,{childList:!0,subtree:!0});function o(t){const a={};return t.integrity&&(a.integrity=t.integrity),t.referrerPolicy&&(a.referrerPolicy=t.referrerPolicy),t.crossOrigin==="use-credentials"?a.credentials="include":t.crossOrigin==="anonymous"?a.credentials="omit":a.credentials="same-origin",a}function s(t){if(t.ep)return;t.ep=!0;const a=o(t);fetch(t.href,a)}})();function n(r,e){return`
    <article class="rounded-3xl border border-stone-200 bg-white px-5 py-5 shadow-[0_10px_30px_rgba(28,25,23,0.04)]">
      <p class="text-[11px] uppercase tracking-[0.24em] text-stone-500">${r}</p>
      <p class="mt-3 text-sm leading-7 text-stone-600">${e}</p>
    </article>
  `}function b({container:r,runtime:e}){const o=window.matchMedia("(prefers-reduced-motion: reduce)").matches;r.innerHTML=`
    <section class="bg-[linear-gradient(180deg,#f7f4ee_0%,#faf8f4_100%)] text-stone-900">
      <div class="mx-auto max-w-[1240px] px-4 py-6 sm:px-6 lg:px-8 lg:py-8">
        <div class="overflow-hidden rounded-[2rem] border border-black/7 bg-[rgba(255,255,255,0.72)] shadow-[0_24px_80px_rgba(57,38,17,0.06)] backdrop-blur">
          <section class="border-b border-black/6 px-5 py-8 sm:px-8 sm:py-10">
            <div class="grid gap-8 lg:grid-cols-[1.05fr_0.95fr] lg:items-end">
              <div class="max-w-2xl">
                <div class="inline-flex items-center gap-2 rounded-full border border-stone-200 bg-white px-3 py-2 text-[11px] uppercase tracking-[0.26em] text-stone-500">
                  <i data-lucide="layout-template" class="h-4 w-4"></i>
                  <span>Scaffold Only</span>
                </div>
                <h1 class="mt-5 text-[clamp(2.6rem,6vw,4.8rem)] font-semibold leading-[0.94] tracking-[-0.04em] text-stone-950">
                  这里是中性脚手架，
                  <span class="block text-stone-600">不是最终交付页面设计。</span>
                </h1>
                <p class="mt-5 max-w-xl text-base leading-8 text-stone-600 sm:text-lg">
                  默认模板只负责提供稳定的运行壳、响应式容器、状态示例与挂载链路。真正的视觉风格、叙事结构和品牌表达，应由当前项目的生成结果决定。
                </p>

                <div class="mt-8 flex flex-wrap gap-3">
                  <a href="#design-checklist" class="inline-flex h-11 items-center rounded-full bg-stone-950 px-5 text-sm font-medium text-stone-50 transition hover:bg-stone-800 active:scale-[0.98]">
                    查看设计检查点
                  </a>
                  <button id="starter-feedback" class="inline-flex h-11 items-center rounded-full border border-stone-300 bg-white px-5 text-sm font-medium text-stone-900 transition hover:bg-stone-50 active:scale-[0.98]">
                    触发反馈示例
                  </button>
                </div>
              </div>

              <div class="grid gap-3 sm:grid-cols-3 lg:grid-cols-1">
                ${n("Runtime","保留 page 挂载、图标刷新、API 代理与预览健康状态。")}
                ${n("Responsive","默认容器和节奏覆盖 PC / Pad / H5，不绑定具体品牌布局。")}
                ${n("States","模板仅示例 Loading / Empty / Error / Active Feedback 的实现挂点。")}
              </div>
            </div>
          </section>

          <section id="design-checklist" class="grid gap-0 lg:grid-cols-[0.82fr_1.18fr]">
            <div class="border-b border-black/6 px-5 py-8 sm:px-8 lg:border-b-0 lg:border-r">
              <p class="text-[11px] uppercase tracking-[0.24em] text-stone-500">Design Handoff</p>
              <h2 class="mt-3 text-3xl font-semibold tracking-[-0.03em] text-stone-950 sm:text-4xl [text-wrap:balance]">
                默认模板把设计要求前置到流程，而不是写死在模板页面里。
              </h2>
              <div class="mt-6 space-y-3">
                ${n("Design Read","先明确页面目标、受众、语气、记忆点，再开始写页面。")}
                ${n("Block Plan","先定首屏、证明区、内容区、CTA 收口，不允许直接套三等分卡片。")}
                ${n("Review Loop","至少经过一次 build / preview 验证和一次页面实看复核后再交付。")}
              </div>
            </div>

            <div class="px-5 py-8 sm:px-8">
              <div class="grid gap-4 sm:grid-cols-2">
                <article class="rounded-[1.7rem] border border-dashed border-stone-300 bg-white/70 p-5">
                  <p class="text-[11px] uppercase tracking-[0.24em] text-stone-500">Hero Slot</p>
                  <p class="mt-4 text-sm leading-7 text-stone-600">
                    在这里替换成当前项目的首屏结构、主文案、主视觉和主 CTA。不要沿用模板文案。
                  </p>
                </article>
                <article class="rounded-[1.7rem] border border-dashed border-stone-300 bg-white/70 p-5">
                  <p class="text-[11px] uppercase tracking-[0.24em] text-stone-500">Proof Slot</p>
                  <p class="mt-4 text-sm leading-7 text-stone-600">
                    在这里放价值证明、案例、规格、功能、场景或数据，不预设品牌气质。
                  </p>
                </article>
                <article class="rounded-[1.7rem] border border-dashed border-stone-300 bg-white/70 p-5">
                  <p class="text-[11px] uppercase tracking-[0.24em] text-stone-500">State Slot</p>
                  <p class="mt-4 text-sm leading-7 text-stone-600">
                    在这里替换成业务相关的 Loading / Empty / Error / Active 反馈。
                  </p>
                </article>
                <article class="rounded-[1.7rem] border border-dashed border-stone-300 bg-white/70 p-5">
                  <p class="text-[11px] uppercase tracking-[0.24em] text-stone-500">CTA Slot</p>
                  <p class="mt-4 text-sm leading-7 text-stone-600">
                    收口区必须服务当前项目目标，不允许保留模板式“继续优化”泛文案。
                  </p>
                </article>
              </div>
            </div>
          </section>

          <section class="border-t border-black/6 px-5 py-8 sm:px-8 sm:py-10">
            <div class="grid gap-4 lg:grid-cols-4">
              <article class="rounded-[1.6rem] border border-black/7 bg-white/78 p-4">
                <p class="text-[11px] uppercase tracking-[0.22em] text-stone-500">Loading</p>
                <div class="mt-4 space-y-2">
                  <div class="h-3 w-3/4 rounded-full bg-stone-200"></div>
                  <div class="h-3 w-full rounded-full bg-stone-200/90"></div>
                  <div class="h-3 w-4/5 rounded-full bg-stone-200/80"></div>
                </div>
              </article>
              <article class="rounded-[1.6rem] border border-black/7 bg-white/78 p-4">
                <p class="text-[11px] uppercase tracking-[0.22em] text-stone-500">Empty</p>
                <p class="mt-4 text-sm leading-7 text-stone-600">空态需要说明下一步，而不是只留一个“暂无数据”。</p>
              </article>
              <article class="rounded-[1.6rem] border border-black/7 bg-[#f8eee7] p-4">
                <p class="text-[11px] uppercase tracking-[0.22em] text-stone-500">Error</p>
                <p class="mt-4 text-sm leading-7 text-stone-700">错误提示应靠近问题源，并明确重试或回退路径。</p>
              </article>
              <article class="rounded-[1.6rem] border border-black/7 bg-[#ecf1e9] p-4">
                <p class="text-[11px] uppercase tracking-[0.22em] text-stone-500">Active Feedback</p>
                <p class="mt-4 text-sm leading-7 text-stone-700">点击、提交、切换都应有即时反馈，不能静默。</p>
              </article>
            </div>
          </section>
        </div>
      </div>

      <div id="starter-toast" class="pointer-events-none fixed bottom-6 left-1/2 z-50 -translate-x-1/2 translate-y-3 rounded-full bg-stone-950 px-5 py-3 text-sm font-medium text-stone-50 opacity-0 shadow-[0_18px_40px_rgba(22,16,10,0.28)] transition-all duration-300">
        已触发默认反馈示例
      </div>
    </section>
  `,e.refreshIcons();const s=r.querySelector("#starter-feedback"),t=document.querySelector("#starter-toast");let a=null;function i(u){t&&(t.textContent=u,t.style.opacity="1",t.style.transform="translate(-50%, 0)",clearTimeout(a),a=setTimeout(()=>{t.style.opacity="0",t.style.transform="translate(-50%, 0.75rem)"},1600))}s==null||s.addEventListener("click",()=>{if(i("这是脚手架级交互反馈示例，交付页中应替换成真实业务动作。"),!o&&window.animate)try{window.animate(s,{scale:[1,.96,1],duration:340,ease:"out(4)"})}catch{}})}function x(r){return r.startsWith("http://")||r.startsWith("https://")||r.startsWith("/")?r:`/${r}`}async function m(r,e={}){var t;const o=x(r);if((t=window.axios)!=null&&t.get)return window.axios.get(o,e);const s=await fetch(o,{method:"GET"});if(!s.ok)throw new Error(`GET ${o} failed: ${s.status}`);return s}async function g(r,e,o={}){var a;const s=x(r);if((a=window.axios)!=null&&a.post)return window.axios.post(s,e,o);const t=await fetch(s,{method:"POST",headers:{"Content-Type":"application/json"},body:e===void 0?void 0:JSON.stringify(e)});if(!t.ok)throw new Error(`POST ${s} failed: ${t.status}`);return t}class d{static getRaw(){return typeof document>"u"?"":document.cookie||""}static getAll(){const e=d.getRaw();return e?e.split(";").reduce((o,s)=>{const t=s.indexOf("=");if(t===-1)return o;const a=s.slice(0,t).trim(),i=s.slice(t+1).trim();return a&&(o[a]=decodeURIComponent(i)),o},{}):{}}static get(e){return d.getAll()[e]}static log(){const e=d.getAll();return console.log("[CookieUtil] 当前 cookie 原始值:",d.getRaw()),console.log("[CookieUtil] 当前 cookie 解析结果:",e),e}}const f={template:"vite-page",pageMode:"single-page",qualityBar:"production-starter"},v={proxyPrefix:"/api",deviceTargets:["PC","Pad","H5"],shellEnabled:!1};function h(){const r={current:null};return{project:f,preview:v,api:{get:m,post:g},refreshIcons(){var e;(e=window.lucide)!=null&&e.createIcons&&window.lucide.createIcons()},registerHealthNode(e){r.current=e},setHealthMessage(e,o="pending"){if(!r.current)return;const s=o==="ready"?"border-emerald-700/15 bg-emerald-50 text-emerald-900":o==="warning"?"border-amber-700/15 bg-amber-50 text-amber-900":"border-black/8 bg-[#f2ebdf] text-stone-700";r.current.className=`rounded-full border px-4 py-2 text-xs sm:text-sm ${s}`,r.current.textContent=e}}}function w(r,e){r.innerHTML=`
    <div class="min-h-screen bg-[linear-gradient(180deg,#f4eee6_0%,#f8f5ef_46%,#fbfaf7_100%)] text-stone-900">
      <div class="mx-auto min-h-screen max-w-[1520px] px-4 py-4 sm:px-6 lg:px-8">
        <div class="grid min-h-[calc(100vh-2rem)] gap-5 lg:grid-cols-[280px_minmax(0,1fr)]">
          <aside class="overflow-hidden rounded-[2rem] border border-black/8 bg-[rgba(255,255,255,0.72)] p-5 shadow-[0_24px_80px_rgba(57,38,17,0.08)] backdrop-blur">
            <div class="flex items-center justify-between">
              <div>
                <p class="text-[11px] uppercase tracking-[0.28em] text-stone-500">WebGen</p>
                <h1 class="mt-2 text-2xl font-semibold tracking-tight text-stone-900">Preview Atelier</h1>
              </div>
              <div class="inline-flex h-11 w-11 items-center justify-center rounded-full bg-stone-900 text-stone-50">
                <i data-lucide="sparkles" class="h-5 w-5"></i>
              </div>
            </div>

            <div class="mt-6 space-y-3 text-sm">
              <div class="rounded-[1.4rem] border border-black/6 bg-white/75 p-4">
                <p class="text-[11px] uppercase tracking-[0.24em] text-stone-500">Template</p>
                <p class="mt-2 font-medium text-stone-900">${e.project.template}</p>
              </div>
              <div class="rounded-[1.4rem] border border-black/6 bg-white/75 p-4">
                <p class="text-[11px] uppercase tracking-[0.24em] text-stone-500">Proxy</p>
                <p class="mt-2 font-medium text-stone-900">${e.preview.proxyPrefix}</p>
              </div>
              <div class="rounded-[1.4rem] border border-black/6 bg-white/75 p-4">
                <p class="text-[11px] uppercase tracking-[0.24em] text-stone-500">Targets</p>
                <p class="mt-2 font-medium text-stone-900">${e.preview.deviceTargets.join(" / ")}</p>
              </div>
            </div>

            <div class="mt-6 rounded-[1.7rem] border border-black/8 bg-stone-900 p-4 text-stone-50">
              <p class="text-[11px] uppercase tracking-[0.24em] text-stone-300">Preview Rules</p>
              <ul class="mt-3 space-y-2 text-sm text-stone-200/85">
                <li>1. 这是运行脚手架，不是最终交付设计</li>
                <li>2. 页面需覆盖 PC / Pad / H5 的安全布局</li>
                <li>3. 交付设计由当前项目生成结果决定</li>
              </ul>
            </div>
          </aside>

          <main class="overflow-hidden rounded-[2.4rem] border border-black/8 bg-white/82 shadow-[0_24px_80px_rgba(57,38,17,0.1)] backdrop-blur">
            <header class="flex flex-col gap-4 border-b border-black/6 px-5 py-5 sm:flex-row sm:items-center sm:justify-between sm:px-7">
              <div>
                <p class="text-[11px] uppercase tracking-[0.28em] text-stone-500">Single Page Starter</p>
                <p class="mt-2 max-w-2xl text-sm leading-7 text-stone-600">
                  这里渲染的是页面挂载区域。外层只保留轻量预览壳，用来提供设备目标、运行状态和中性容器，不预设最终品牌风格。
                </p>
              </div>
              <div id="preview-health" class="rounded-full border border-black/8 bg-[#f2ebdf] px-4 py-2 text-xs text-stone-700 shadow-[inset_0_1px_0_rgba(255,255,255,0.4)]">
                正在初始化页面预览…
              </div>
            </header>

            <div class="bg-[linear-gradient(180deg,rgba(255,255,255,0.72)_0%,rgba(249,245,238,0.86)_100%)] p-3 sm:p-4">
              <div class="overflow-hidden rounded-[1.8rem] border border-black/6 bg-[#f8f4ec] shadow-[inset_0_1px_0_rgba(255,255,255,0.65)]">
                <div id="generated-page-root"></div>
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  `,e.refreshIcons();const o=r.querySelector("#preview-health"),s=r.querySelector("#generated-page-root");return e.registerHealthNode(o),{healthNode:o,pageRoot:s}}d.log();const p=document.querySelector("#app"),y=new URLSearchParams(window.location.search),c=y.get("previewShell")==="1",l=h();l.api={get:m,post:g};l.preview.shellEnabled=c;const k=c?w(p,l):{pageRoot:p};b({container:k.pageRoot,runtime:l});c&&l.setHealthMessage("页面骨架已挂载，可继续补业务内容、数据和品牌素材。","ready");
