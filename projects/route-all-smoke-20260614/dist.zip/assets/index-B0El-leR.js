(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const t of document.querySelectorAll('link[rel="modulepreload"]'))a(t);new MutationObserver(t=>{for(const i of t)if(i.type==="childList")for(const l of i.addedNodes)l.tagName==="LINK"&&l.rel==="modulepreload"&&a(l)}).observe(document,{childList:!0,subtree:!0});function r(t){const i={};return t.integrity&&(i.integrity=t.integrity),t.referrerPolicy&&(i.referrerPolicy=t.referrerPolicy),t.crossOrigin==="use-credentials"?i.credentials="include":t.crossOrigin==="anonymous"?i.credentials="omit":i.credentials="same-origin",i}function a(t){if(t.ep)return;t.ep=!0;const i=r(t);fetch(t.href,i)}})();function c({container:s,runtime:e}){s.innerHTML=`
    <section class="space-y-6">
      <div class="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm text-slate-200">
        <i data-lucide="sparkles" class="h-4 w-4"></i>
        <span>Generated Page Module</span>
      </div>

      <div class="grid gap-6 lg:grid-cols-[1.25fr_0.95fr]">
        <article class="space-y-6">
          <div class="space-y-4">
            <p class="text-sm uppercase tracking-[0.32em] text-cyan-300">OpenClaw · Vite · Mounted Page</p>
            <h2 class="max-w-3xl text-4xl font-semibold leading-tight text-white sm:text-5xl">
              生成页只负责业务内容，预览壳负责服务、代理和运行时状态。
            </h2>
            <p class="max-w-2xl text-base leading-8 text-slate-300 sm:text-lg">
              现在页面不是直接接管整个入口，而是作为 <code>src/generated/page.js</code> 模块挂载进
              Vite 预览壳，这样 agent 可以迭代页面而不破坏预览基础设施。
            </p>
          </div>

          <div class="grid gap-4 md:grid-cols-2">
            <div class="rounded-3xl border border-white/10 bg-white/5 p-5">
              <p class="text-sm text-slate-400">运行模式</p>
              <p class="mt-3 text-xl font-medium text-white">${e.project.pageMode}</p>
            </div>
            <div class="rounded-3xl border border-white/10 bg-white/5 p-5">
              <p class="text-sm text-slate-400">适配目标</p>
              <p class="mt-3 text-xl font-medium text-white">${e.preview.deviceTargets.join(" / ")}</p>
            </div>
          </div>
        </article>

        <aside class="rounded-[1.75rem] border border-cyan-400/20 bg-cyan-400/10 p-6 shadow-2xl shadow-cyan-900/20">
          <p class="text-sm uppercase tracking-[0.28em] text-cyan-100">Delivery Contract</p>
          <ul class="mt-5 space-y-3 text-sm leading-7 text-cyan-50">
            <li>1. 页面代码写入 <code>src/generated/</code></li>
            <li>2. 入口壳由 <code>src/main.js</code> 固定托管</li>
            <li>3. 运行时统一提供 <code>/api</code> 代理访问</li>
            <li>4. 生成页通过挂载协议接入预览服务</li>
          </ul>
        </aside>
      </div>
    </section>
  `,e.refreshIcons()}function n(s){return s.startsWith("http://")||s.startsWith("https://")||s.startsWith("/")?s:`/${s}`}async function p(s,e={}){var t;const r=n(s);if((t=window.axios)!=null&&t.get)return window.axios.get(r,e);const a=await fetch(r,{method:"GET"});if(!a.ok)throw new Error(`GET ${r} failed: ${a.status}`);return a}async function x(s,e,r={}){var i;const a=n(s);if((i=window.axios)!=null&&i.post)return window.axios.post(a,e,r);const t=await fetch(a,{method:"POST",headers:{"Content-Type":"application/json"},body:e===void 0?void 0:JSON.stringify(e)});if(!t.ok)throw new Error(`POST ${a} failed: ${t.status}`);return t}const u={template:"vite-page",pageMode:"single-page"},g={proxyPrefix:"/api",deviceTargets:["PC","Pad","H5"]};function m(){const s={current:null};return{project:u,preview:g,api:{get:p,post:x},refreshIcons(){var e;(e=window.lucide)!=null&&e.createIcons&&window.lucide.createIcons()},registerHealthNode(e){s.current=e},setHealthMessage(e,r="pending"){s.current&&(s.current.className=r==="ready"?"mt-4 rounded-2xl border border-emerald-400/20 bg-emerald-400/10 px-4 py-3 text-sm text-emerald-200":r==="warning"?"mt-4 rounded-2xl border border-amber-400/20 bg-amber-400/10 px-4 py-3 text-sm text-amber-100":"mt-4 rounded-2xl border border-sky-400/20 bg-sky-400/10 px-4 py-3 text-sm text-sky-100",s.current.textContent=e)}}}function h(s,e){s.innerHTML=`
    <main class="min-h-screen bg-[radial-gradient(circle_at_top,_rgba(14,165,233,0.18),_transparent_28%),linear-gradient(180deg,#020617_0%,#0f172a_100%)] text-slate-50">
      <section class="mx-auto flex min-h-screen w-full max-w-7xl flex-col gap-8 px-4 py-6 sm:px-6 lg:px-8">
        <header class="rounded-3xl border border-white/10 bg-slate-900/70 p-5 shadow-2xl shadow-slate-950/30 backdrop-blur">
          <div class="flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
            <div class="space-y-3">
              <div class="inline-flex w-fit items-center gap-2 rounded-full border border-sky-400/30 bg-sky-400/10 px-3 py-1 text-xs font-medium uppercase tracking-[0.24em] text-sky-200">
                <i data-lucide="monitor-play" class="h-4 w-4"></i>
                <span>Preview Shell</span>
              </div>
              <div>
                <h1 class="text-3xl font-semibold tracking-tight text-white sm:text-4xl">
                  WebGen 项目预览运行时
                </h1>
                <p class="mt-2 max-w-3xl text-sm leading-7 text-slate-300 sm:text-base">
                  Vite 负责提供稳定本地服务，生成页面以模块形式挂载到预览壳中；代理、状态和调试信息由壳层统一管理。
                </p>
              </div>
            </div>
            <dl class="grid gap-3 text-sm text-slate-300 sm:grid-cols-3">
              <div class="rounded-2xl border border-white/10 bg-white/5 px-4 py-3">
                <dt class="text-xs uppercase tracking-[0.2em] text-slate-400">Template</dt>
                <dd class="mt-2 font-medium text-white">${e.project.template}</dd>
              </div>
              <div class="rounded-2xl border border-white/10 bg-white/5 px-4 py-3">
                <dt class="text-xs uppercase tracking-[0.2em] text-slate-400">Proxy</dt>
                <dd class="mt-2 font-medium text-white">${e.preview.proxyPrefix}</dd>
              </div>
              <div class="rounded-2xl border border-white/10 bg-white/5 px-4 py-3">
                <dt class="text-xs uppercase tracking-[0.2em] text-slate-400">Devices</dt>
                <dd class="mt-2 font-medium text-white">${e.preview.deviceTargets.join(" / ")}</dd>
              </div>
            </dl>
          </div>
          <div id="preview-health" class="mt-4 rounded-2xl border border-sky-400/20 bg-sky-400/10 px-4 py-3 text-sm text-sky-100">
            正在初始化预览运行时…
          </div>
        </header>

        <section class="grid gap-6 xl:grid-cols-[minmax(0,1fr)_320px]">
          <div class="rounded-[2rem] border border-white/10 bg-slate-950/60 p-3 shadow-[0_24px_80px_rgba(2,6,23,0.55)]">
            <div class="rounded-[1.5rem] border border-white/10 bg-slate-900/50 p-4 sm:p-6">
              <div id="generated-page-root"></div>
            </div>
          </div>
          <aside class="space-y-4 rounded-[2rem] border border-white/10 bg-white/5 p-5 shadow-2xl shadow-slate-950/30 backdrop-blur">
            <div>
              <p class="text-xs uppercase tracking-[0.2em] text-slate-400">Mount Contract</p>
              <p class="mt-2 text-sm leading-7 text-slate-300">
                业务生成页只负责导出 <code>mountPage({ container, runtime })</code>，入口层始终由预览壳托管。
              </p>
            </div>
            <div class="rounded-3xl border border-white/10 bg-slate-950/40 p-4">
              <p class="text-sm font-medium text-white">统一壳层能力</p>
              <ul class="mt-3 space-y-2 text-sm text-slate-300">
                <li>1. 本地 Vite 服务</li>
                <li>2. <code>/api</code> 代理映射</li>
                <li>3. 预览健康状态展示</li>
                <li>4. 设备适配目标提示</li>
              </ul>
            </div>
          </aside>
        </section>
      </section>
    </main>
  `,e.refreshIcons();const r=s.querySelector("#preview-health"),a=s.querySelector("#generated-page-root");return e.registerHealthNode(r),{healthNode:r,pageRoot:a}}class d{static getRaw(){return typeof document>"u"?"":document.cookie||""}static getAll(){const e=d.getRaw();return e?e.split(";").reduce((r,a)=>{const t=a.indexOf("=");if(t===-1)return r;const i=a.slice(0,t).trim(),l=a.slice(t+1).trim();return i&&(r[i]=decodeURIComponent(l)),r},{}):{}}static get(e){return d.getAll()[e]}static log(){const e=d.getAll();return console.log("[CookieUtil] 当前 cookie 原始值:",d.getRaw()),console.log("[CookieUtil] 当前 cookie 解析结果:",e),e}}d.log();const f=document.querySelector("#app"),o=m(),w=h(f,o);c({container:w.pageRoot,runtime:o});o.setHealthMessage("正在检查 `/api/health` 示例请求能力…","pending");o.api.get("/api/health").then(()=>{o.setHealthMessage("本地代理示例可用：`/api/health` 已返回成功。","ready")}).catch(()=>{o.setHealthMessage("尚未配置可用的 `/api/health` 远端目标。这是预期状态，可在 `.env` 中配置代理目标后重试。","warning")});
