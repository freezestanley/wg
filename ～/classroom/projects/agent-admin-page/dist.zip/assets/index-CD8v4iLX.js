(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const a of document.querySelectorAll('link[rel="modulepreload"]'))n(a);new MutationObserver(a=>{for(const r of a)if(r.type==="childList")for(const d of r.addedNodes)d.tagName==="LINK"&&d.rel==="modulepreload"&&n(d)}).observe(document,{childList:!0,subtree:!0});function s(a){const r={};return a.integrity&&(r.integrity=a.integrity),a.referrerPolicy&&(r.referrerPolicy=a.referrerPolicy),a.crossOrigin==="use-credentials"?r.credentials="include":a.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function n(a){if(a.ep)return;a.ep=!0;const r=s(a);fetch(a.href,r)}})();const h=[{key:"dashboard",label:"仪表盘",icon:"layout-dashboard",path:"/dashboard"},{key:"users",label:"用户管理",icon:"users",children:[{key:"users-all",label:"所有用户",path:"/users/all"},{key:"users-roles",label:"角色管理",path:"/users/roles"}]},{key:"content",label:"内容管理",icon:"folder-kanban",children:[{key:"content-posts",label:"文章",path:"/content/posts"},{key:"content-comments",label:"评论",path:"/content/comments"}]},{key:"settings",label:"系统设置",icon:"settings-2",path:"/settings"}],_={"/dashboard":{title:"仪表盘",description:"查看系统整体运行情况、关键指标和待处理事项。",cards:[{title:"今日活跃用户",value:"12,480",note:"较昨日 +8.2%"},{title:"待审核内容",value:"84",note:"需优先处理 12 条"},{title:"系统告警",value:"3",note:"2 条中风险，1 条低风险"}],sections:[{title:"最近动态",type:"list",rows:["09:32 新用户批量导入完成","10:15 评论审核规则已更新","11:08 系统通知模板已发布"]},{title:"待办事项",type:"list",rows:["检查 3 条异常登录告警","完成内容频道权限复核","确认本周运营公告发布时间"]}]},"/users/all":{title:"所有用户",description:"集中查看用户列表、状态与注册来源。",table:{columns:["用户名","手机号","角色","状态","注册时间","操作"],rows:[["陈小北","138****2198","管理员","正常","2026-06-12 09:20","查看 / 编辑"],["李安然","187****6632","编辑","冻结","2026-06-15 13:42","查看 / 解冻"],["王若川","139****1021","运营","正常","2026-06-19 18:06","查看 / 分配角色"]]}},"/users/roles":{title:"角色管理",description:"维护后台角色与权限范围。",cards:[{title:"角色总数",value:"8",note:"含 2 个系统内置角色"},{title:"待审批变更",value:"2",note:"涉及菜单与数据权限"}],sections:[{title:"角色清单",type:"table",columns:["角色名称","成员数","数据权限","最后修改","操作"],rows:[["超级管理员","2","全部","2026-06-20 10:08","编辑"],["内容运营","14","内容中心","2026-06-19 16:32","编辑"],["审核专员","6","评论与文章审核","2026-06-18 14:26","编辑"]]}]},"/content/posts":{title:"文章",description:"管理文章发布状态、频道归类与作者信息。",table:{columns:["标题","频道","作者","状态","发布时间","操作"],rows:[["2026 夏季活动预告","活动运营","张明","已发布","2026-06-20 09:00","查看 / 下线"],["社区规范更新说明","公告","王悦","草稿","--","编辑 / 发布"],["功能上新周报","产品动态","赵宁","待审核","2026-06-19 17:20","审核"]]}},"/content/comments":{title:"评论",description:"处理评论审核、违规拦截与人工复核。",sections:[{title:"审核队列",type:"table",columns:["评论内容","来源文章","用户","风险等级","提交时间","操作"],rows:[["这个活动规则不太清楚","2026 夏季活动预告","陈小北","低","2026-06-20 11:42","通过 / 驳回"],["包含敏感词内容（示例）","社区规范更新说明","匿名用户","高","2026-06-20 12:06","复核"],["建议增加筛选功能","功能上新周报","李安然","低","2026-06-20 12:58","通过"]]}]},"/settings":{title:"系统设置",description:"维护系统参数、通知模板和基础配置。",sections:[{title:"基础配置",type:"form",fields:[["系统名称","企业后台管理系统"],["默认语言","简体中文"],["时区","Asia/Shanghai"],["登录保护","已启用二次验证"]]},{title:"通知模板",type:"list",rows:["用户注册通知","评论审核通知","系统告警通知"]}]}},P=[{title:"评论审核队列新增 12 条待处理",time:"2 分钟前",unread:!0},{title:"角色“内容运营”权限已变更",time:"18 分钟前",unread:!0},{title:"系统将于今晚 23:00 进行例行维护",time:"1 小时前",unread:!1}];function i(e){return String(e).replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#39;")}function g(){return"/dashboard"}function k(e){var t;return((t=h.find(s=>{var n;return(n=s.children)==null?void 0:n.some(a=>a.path===e)}))==null?void 0:t.key)||null}function T(e){var a;const t=h.find(r=>{var d;return r.path===e||((d=r.children)==null?void 0:d.some(b=>b.path===e))}),s=[{label:"首页",path:"/dashboard"}];if(!t)return s;s.push({label:t.label,path:t.path||e});const n=(a=t.children)==null?void 0:a.find(r=>r.path===e);return n&&s.push({label:n.label,path:n.path}),s}function C(e,t,s=0){var l;const n=Array.isArray(e.children),a=(l=e.children)==null?void 0:l.some(c=>c.path===t.routePath),r=t.expandedMenus.includes(e.key)||a,d=e.path===t.routePath,b=`<span class="nav-item__label">${i(e.label)}</span>`,v=`<span class="nav-item__icon"><i data-lucide="${e.icon||"dot"}"></i></span>`;return n?`
    <div class="nav-group ${r?"is-open":""} ${t.sidebarCollapsed?"is-collapsed":""}">
      <button class="nav-item nav-item--group ${a?"is-active":""}" data-toggle-menu="${e.key}">
        ${v}
        ${b}
        <span class="nav-item__arrow"><i data-lucide="chevron-down"></i></span>
      </button>
      <div class="nav-submenu">
        ${e.children.map(c=>`
              <button class="nav-subitem ${c.path===t.routePath?"is-active":""}" data-route="${c.path}" data-close-drawer="1">
                <span class="nav-subitem__dot"></span>
                <span>${i(c.label)}</span>
              </button>
            `).join("")}
      </div>
    </div>
  `:`
      <button class="nav-item ${d?"is-active":""} ${t.sidebarCollapsed?"is-collapsed":""}" data-route="${e.path}" data-close-drawer="1">
        ${v}
        ${b}
      </button>
    `}function j(e){return`
    <aside class="app-sidebar ${e.sidebarCollapsed?"is-collapsed":""} ${e.drawerOpen?"is-drawer-open":""}">
      <div class="sidebar__header">
        <button class="sidebar__logo" data-route="/dashboard" data-close-drawer="1">
          <span class="sidebar__logo-mark">A</span>
          <span class="sidebar__logo-text">Admin System</span>
        </button>
        <button class="sidebar__collapse-btn" id="sidebar-toggle" aria-label="切换侧栏">
          <i data-lucide="panel-left-close"></i>
        </button>
      </div>
      <nav class="sidebar__nav" aria-label="主导航">
        ${h.map(t=>C(t,e)).join("")}
      </nav>
    </aside>
  `}function L(e){const t=P.filter(s=>s.unread).length;return`
    <header class="app-topbar">
      <div class="topbar__left">
        <button class="topbar__menu-btn" id="drawer-toggle" aria-label="展开导航">
          <i data-lucide="menu"></i>
        </button>
        <div class="topbar__brand">
          <span class="topbar__brand-mark">A</span>
          <div>
            <strong>后台管理系统</strong>
            <span>Admin Control Center</span>
          </div>
        </div>
      </div>
      <div class="topbar__right">
        <button class="topbar__icon-btn" id="notification-toggle" aria-label="通知中心">
          <i data-lucide="bell"></i>
          ${t?`<span class="badge">${t}</span>`:""}
        </button>
        <div class="user-menu-wrap">
          <button class="user-menu-trigger" id="user-menu-toggle">
            <span class="avatar">Z</span>
            <span class="user-meta">
              <strong>张管理员</strong>
              <em>超级管理员</em>
            </span>
            <i data-lucide="chevron-down"></i>
          </button>
          <div class="user-dropdown ${e.userMenuOpen?"is-open":""}">
            <button data-toast="已打开个人中心（mock）">个人中心</button>
            <button data-toast="已打开账号设置（mock）">账号设置</button>
            <button data-toast="已退出登录（mock）">退出登录</button>
          </div>
        </div>
      </div>
    </header>
  `}function R(e){return`
    <aside class="notification-panel ${e.notificationOpen?"is-open":""}">
      <div class="notification-panel__head">
        <h3>通知中心</h3>
        <button class="text-btn" data-toast="全部通知已标记已读（mock）">全部已读</button>
      </div>
      <div class="notification-list">
        ${P.map(t=>`
            <article class="notification-item ${t.unread?"is-unread":""}">
              <h4>${i(t.title)}</h4>
              <p>${i(t.time)}</p>
            </article>
          `).join("")}
      </div>
    </aside>
  `}function q(e){const t=T(e);return`
    <nav class="breadcrumbs" aria-label="面包屑">
      ${t.map((s,n)=>`
            <button class="breadcrumb-item ${n===t.length-1?"is-current":""}" ${n===t.length-1?"disabled":`data-route="${s.path}"`}>
              ${i(s.label)}
            </button>
          `).join('<span class="breadcrumb-separator">/</span>')}
    </nav>
  `}function I(e){return`
    <section class="content-cards">
      ${e.map(t=>`
            <article class="info-card">
              <span>${i(t.title)}</span>
              <strong>${i(t.value)}</strong>
              <p>${i(t.note)}</p>
            </article>
          `).join("")}
    </section>
  `}function E(e){return`
    <div class="content-table-wrap">
      <table class="content-table">
        <thead>
          <tr>${e.columns.map(t=>`<th>${i(t)}</th>`).join("")}</tr>
        </thead>
        <tbody>
          ${e.rows.map(t=>`<tr>${t.map(s=>`<td>${i(s)}</td>`).join("")}</tr>`).join("")}
        </tbody>
      </table>
    </div>
  `}function N(e){return e.type==="list"?`
      <section class="content-section">
        <div class="content-section__head"><h3>${i(e.title)}</h3></div>
        <div class="content-list">
          ${e.rows.map(t=>`<div class="content-list__item">${i(t)}</div>`).join("")}
        </div>
      </section>
    `:e.type==="table"?`
      <section class="content-section">
        <div class="content-section__head"><h3>${i(e.title)}</h3></div>
        ${E(e)}
      </section>
    `:e.type==="form"?`
      <section class="content-section">
        <div class="content-section__head"><h3>${i(e.title)}</h3></div>
        <div class="form-grid">
          ${e.fields.map(([t,s])=>`
                <label class="form-item">
                  <span>${i(t)}</span>
                  <input value="${i(s)}" readonly />
                </label>
              `).join("")}
        </div>
      </section>
    `:""}function H(e){const t=_[e]||_[g()];return`
    <section class="page-card">
      <div class="page-card__head">
        <div>
          <h1>${i(t.title)}</h1>
          <p>${i(t.description)} 当前页面包含关键 metric / 数据 / 规格占位区，用于证明后台信息架构与操作路径。</p>
        </div>
        <div class="page-card__actions">
          <button class="secondary-btn" data-toast="已触发次级操作（mock）">查看规格</button>
          <button class="primary-btn" data-toast="已触发主操作（mock）">开始处理</button>
        </div>
      </div>
      ${t.cards?I(t.cards):""}
      ${t.table?E(t.table):""}
      ${t.sections?t.sections.map(s=>N(s)).join(""):""}
    </section>
  `}function W(e){return`
    <div class="app-shell ${e.sidebarCollapsed?"sidebar-collapsed":""}">
      <div class="app-overlay ${e.drawerOpen?"is-visible":""}" id="app-overlay"></div>
      ${j(e)}
      <div class="app-main">
        ${L(e)}
        ${R(e)}
        <main class="app-content">
          <div class="content-scroll-area">
            ${q(e.routePath)}
            ${H(e.routePath)}
          </div>
        </main>
      </div>
      <div class="toast ${e.toast?"is-visible":""}" role="status" aria-live="polite">${i(e.toast||"")}</div>
    </div>
  `}function B({container:e,runtime:t}){var c;const s={routePath:g(),expandedMenus:[k(g())].filter(Boolean),sidebarCollapsed:window.innerWidth<=960,drawerOpen:!1,notificationOpen:!1,userMenuOpen:!1,toast:""};let n=null;const a=o=>{s.toast=o,l(),clearTimeout(n),n=window.setTimeout(()=>{s.toast="",l()},2200)},r=o=>{s.routePath=o;const p=k(o);p&&!s.expandedMenus.includes(p)&&s.expandedMenus.push(p),s.drawerOpen=!1,s.notificationOpen=!1,s.userMenuOpen=!1,l()},d=o=>{s.expandedMenus=s.expandedMenus.includes(o)?s.expandedMenus.filter(p=>p!==o):[...s.expandedMenus,o],l()},b=()=>{var o,p,x,y,$;e.querySelectorAll("[data-route]").forEach(u=>{u.addEventListener("click",()=>r(u.dataset.route))}),e.querySelectorAll("[data-toggle-menu]").forEach(u=>{u.addEventListener("click",()=>d(u.dataset.toggleMenu))}),e.querySelectorAll("[data-toast]").forEach(u=>{u.addEventListener("click",()=>a(u.dataset.toast))}),(o=e.querySelector("#sidebar-toggle"))==null||o.addEventListener("click",()=>{s.sidebarCollapsed=!s.sidebarCollapsed,l()}),(p=e.querySelector("#drawer-toggle"))==null||p.addEventListener("click",()=>{s.drawerOpen=!0,l()}),(x=e.querySelector("#app-overlay"))==null||x.addEventListener("click",()=>{s.drawerOpen=!1,s.notificationOpen=!1,s.userMenuOpen=!1,l()}),(y=e.querySelector("#notification-toggle"))==null||y.addEventListener("click",()=>{s.notificationOpen=!s.notificationOpen,s.userMenuOpen=!1,l()}),($=e.querySelector("#user-menu-toggle"))==null||$.addEventListener("click",()=>{s.userMenuOpen=!s.userMenuOpen,s.notificationOpen=!1,l()})},v=()=>{const o=window.innerWidth<=960;o&&(s.sidebarCollapsed=!0),o||(s.drawerOpen=!1),l()},l=()=>{var o;e.innerHTML=W(s),(o=window.lucide)!=null&&o.createIcons&&window.lucide.createIcons(),b()};l(),window.addEventListener("resize",v),(c=t==null?void 0:t.setHealthMessage)==null||c.call(t,"后台整体布局已加载，可切换示例路由并验证侧栏/顶栏交互。","ready")}function M(e){return e.startsWith("http://")||e.startsWith("https://")||e.startsWith("/")?e:`/${e}`}async function S(e,t={}){var a;const s=M(e);if((a=window.axios)!=null&&a.get)return window.axios.get(s,t);const n=await fetch(s,{method:"GET"});if(!n.ok)throw new Error(`GET ${s} failed: ${n.status}`);return n}async function A(e,t,s={}){var r;const n=M(e);if((r=window.axios)!=null&&r.post)return window.axios.post(n,t,s);const a=await fetch(n,{method:"POST",headers:{"Content-Type":"application/json"},body:t===void 0?void 0:JSON.stringify(t)});if(!a.ok)throw new Error(`POST ${n} failed: ${a.status}`);return a}class f{static getRaw(){return typeof document>"u"?"":document.cookie||""}static getAll(){const t=f.getRaw();return t?t.split(";").reduce((s,n)=>{const a=n.indexOf("=");if(a===-1)return s;const r=n.slice(0,a).trim(),d=n.slice(a+1).trim();return r&&(s[r]=decodeURIComponent(d)),s},{}):{}}static get(t){return f.getAll()[t]}static log(){const t=f.getAll();return console.log("[CookieUtil] 当前 cookie 原始值:",f.getRaw()),console.log("[CookieUtil] 当前 cookie 解析结果:",t),t}}const G={template:"vite-page",pageMode:"single-page",qualityBar:"production-starter"},F={proxyPrefix:"/api",deviceTargets:["PC","Pad","H5"],shellEnabled:!1};function U(){const e={current:null};return{project:G,preview:F,api:{get:S,post:A},refreshIcons(){var t;(t=window.lucide)!=null&&t.createIcons&&window.lucide.createIcons()},registerHealthNode(t){e.current=t},setHealthMessage(t,s="pending"){if(!e.current)return;const n=s==="ready"?"border-emerald-700/15 bg-emerald-50 text-emerald-900":s==="warning"?"border-amber-700/15 bg-amber-50 text-amber-900":"border-black/8 bg-[#f2ebdf] text-stone-700";e.current.className=`rounded-full border px-4 py-2 text-xs sm:text-sm ${n}`,e.current.textContent=t}}}function z(e,t){e.innerHTML=`
    <div class="min-h-screen bg-[linear-gradient(180deg,#f4eee6_0%,#f8f5ef_46%,#fbfaf7_100%)] text-stone-900">
      <div class="mx-auto min-h-screen max-w-[1520px] px-4 py-4 sm:px-6 lg:px-8">
        <div class="grid min-h-[calc(100vh-2rem)] gap-5 lg:grid-cols-[280px_minmax(0,1fr)]">
          <aside class="overflow-hidden rounded-[2rem] border border-black/8 bg-[rgba(255,255,255,0.72)] p-5 shadow-[0_24px_80px_rgba(57,38,17,0.08)] backdrop-blur">
            <div class="flex items-center justify-between">
              <div>
                <p class="text-[11px] uppercase tracking-[0.28em] text-stone-500">WebGen</p>
                <h1 class="mt-2 text-2xl font-semibold tracking-tight text-stone-900">Preview Atelier</h1>
              </div>
              <div class="inline-flex h-11 w-11 items-center justify-center rounded-full bg-stone-900 text-stone-50">
                <i data-lucide="sparkles" class="h-5 w-5"></i>
              </div>
            </div>

            <div class="mt-6 space-y-3 text-sm">
              <div class="rounded-[1.4rem] border border-black/6 bg-white/75 p-4">
                <p class="text-[11px] uppercase tracking-[0.24em] text-stone-500">Template</p>
                <p class="mt-2 font-medium text-stone-900">${t.project.template}</p>
              </div>
              <div class="rounded-[1.4rem] border border-black/6 bg-white/75 p-4">
                <p class="text-[11px] uppercase tracking-[0.24em] text-stone-500">Proxy</p>
                <p class="mt-2 font-medium text-stone-900">${t.preview.proxyPrefix}</p>
              </div>
              <div class="rounded-[1.4rem] border border-black/6 bg-white/75 p-4">
                <p class="text-[11px] uppercase tracking-[0.24em] text-stone-500">Targets</p>
                <p class="mt-2 font-medium text-stone-900">${t.preview.deviceTargets.join(" / ")}</p>
              </div>
            </div>

            <div class="mt-6 rounded-[1.7rem] border border-black/8 bg-stone-900 p-4 text-stone-50">
              <p class="text-[11px] uppercase tracking-[0.24em] text-stone-300">Preview Rules</p>
              <ul class="mt-3 space-y-2 text-sm text-stone-200/85">
                <li>1. 这是运行脚手架，不是最终交付设计</li>
                <li>2. 页面需覆盖 PC / Pad / H5 的安全布局</li>
                <li>3. 交付设计由当前项目生成结果决定</li>
              </ul>
            </div>
          </aside>

          <main class="overflow-hidden rounded-[2.4rem] border border-black/8 bg-white/82 shadow-[0_24px_80px_rgba(57,38,17,0.1)] backdrop-blur">
            <header class="flex flex-col gap-4 border-b border-black/6 px-5 py-5 sm:flex-row sm:items-center sm:justify-between sm:px-7">
              <div>
                <p class="text-[11px] uppercase tracking-[0.28em] text-stone-500">Single Page Starter</p>
                <p class="mt-2 max-w-2xl text-sm leading-7 text-stone-600">
                  这里渲染的是页面挂载区域。外层只保留轻量预览壳，用来提供设备目标、运行状态和中性容器，不预设最终品牌风格。
                </p>
              </div>
              <div id="preview-health" class="rounded-full border border-black/8 bg-[#f2ebdf] px-4 py-2 text-xs text-stone-700 shadow-[inset_0_1px_0_rgba(255,255,255,0.4)]">
                正在初始化页面预览…
              </div>
            </header>

            <div class="bg-[linear-gradient(180deg,rgba(255,255,255,0.72)_0%,rgba(249,245,238,0.86)_100%)] p-3 sm:p-4">
              <div class="overflow-hidden rounded-[1.8rem] border border-black/6 bg-[#f8f4ec] shadow-[inset_0_1px_0_rgba(255,255,255,0.65)]">
                <div id="generated-page-root"></div>
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  `,t.refreshIcons();const s=e.querySelector("#preview-health"),n=e.querySelector("#generated-page-root");return t.registerHealthNode(s),{healthNode:s,pageRoot:n}}f.log();const O=document.querySelector("#app"),D=new URLSearchParams(window.location.search),w=D.get("previewShell")==="1",m=U();m.api={get:S,post:A};m.preview.shellEnabled=w;const J=w?z(O,m):{pageRoot:O};B({container:J.pageRoot,runtime:m});w&&m.setHealthMessage("页面骨架已挂载，可继续补业务内容、数据和品牌素材。","ready");
